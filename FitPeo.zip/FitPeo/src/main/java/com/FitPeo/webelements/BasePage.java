package com.FitPeo.webelements;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePage {
	
	WebDriver driver=new ChromeDriver();
    Actions ac=new Actions(driver);
    public static WebElement element;
	
	public String openpage(String URL)
	{
		driver.get(URL);
		  return URL;
	}

	public String getcurrenturl()
	{
		return driver.getCurrentUrl();
	}
	
	public void clickbutton(String path)
	{
		driver.findElement(By.xpath(path)).click();
	}
	
	public void maximize()
	{
		driver.manage().window().maximize();
	}
	
	public void scrolltoelement(String Xpath) throws InterruptedException
	{
		System.out.println("Inside scrolltoelement");
		ac.sendKeys(Keys.ARROW_DOWN,Keys.ARROW_DOWN);
		Thread.sleep(20000);
		System.out.println("Scroll sucess");
		element=driver.findElement(By.xpath(Xpath));
		System.out.println("trying to find slider");
		ac.scrollToElement(element).click().build().perform();
		
	}
	
	public void scrolldowntillelementvisible(WebElement Xpath)
	{
		ac.moveToElement(Xpath).click().build().perform(); 
	}
	
	
	public void slider(String Xpathofdrager, int dragtill)
	{
		System.out.println("Inside slider");
		element=driver.findElement(By.xpath(Xpathofdrager));
		ac.moveToElement(element).clickAndHold().moveByOffset(dragtill,0).release().perform();

	}
	public void quitbrowser()
	{
		driver.quit();
	}
}
