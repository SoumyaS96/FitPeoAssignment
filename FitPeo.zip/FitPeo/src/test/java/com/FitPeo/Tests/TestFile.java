package com.FitPeo.Tests;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.FitPeo.Productpage.RevenuePage;
import com.FitPeo.Productpage.homepage;

public class TestFile  {
	homepage hp= new homepage();
	RevenuePage rp=new RevenuePage();
	
	@Test(priority=1)
	public void openhomepage() throws InterruptedException 	//TD-1 Navigate to FitPeo Homepage
	{
		hp.openhomepage();
		hp.currenturl();

		
	}
	
	@Test(priority=2)
	public void openrevenuepage() throws InterruptedException //TD-2 Navigate to the Revenue Calculator Page
	{
		rp.revenuepage();
		Thread.sleep(20000);
		rp.currenturl();
	}
	
	@Test(priority=3)
	public void scrolldowntoslider() throws InterruptedException//TD-3 Scroll Down to the Slider section
	{
		Thread.sleep(20000);
		rp.scrolldowntoslider();
	}
	
	@Test(priority=4)
	public void sliderverification() throws InterruptedException //TD-4 Adjust the Slider
	{
		rp.slidervalueverification();
	}
	
	@Test(priority=5)
	public void slidertextverification() throws InterruptedException//TD-5 Update the Text Field &  TD-6 Validate Slider Value
	{
		rp.slidertextverfication();
	}
	
	@Test(priority=6)
	public void CPTcheckboxverification() throws InterruptedException // TD-7 Scroll down further and select the checkboxes for CPT-99091, CPT-99453, CPT-99454, and CPT-99474.
	{
		rp.CPTcheckboxverification();
		
	}
	
	@Test(priority=7)
	public void totalrecurringremburstment() throws InterruptedException// TD-8 Validate Total Recurring Reimbursement 
	{
		rp.totalrecurringmonthreimbursementvalidation();
	}
	
	@Test(priority=8)
	public void totalrecurringremburstmentonheader() throws InterruptedException//TD-9 Verify that the header displaying Total Recurring Reimbursement for all Patients Per Month: shows the value $110700.
	{
	
		rp.totalrecurringmonthreimbursementheadervalidation();
	}
	
	
	

}
