package com.FitPeo.Productpage;

import com.FitPeo.webelements.BasePage;

public class homepage extends BasePage  {
	
	BasePage bp=new BasePage();
	public void openhomepage()
	{
		bp.openpage("https://www.fitpeo.com/");
	}
	
	public void currenturl()
	{
		String currenturl= bp.getcurrenturl();
		System.out.println(currenturl);
	}
	
	
	
	
	
}
