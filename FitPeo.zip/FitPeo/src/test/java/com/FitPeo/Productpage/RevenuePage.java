package com.FitPeo.Productpage;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.FitPeo.webelements.BasePage;

public class RevenuePage extends BasePage {
	
	BasePage bp=new BasePage();


	public void revenuepage() throws InterruptedException
	{
		System.out.println("Inside revenue page");
        bp.openpage("https://www.fitpeo.com/");
        Thread.sleep(20000);
        bp.maximize();
        Thread.sleep(20000);
		bp.clickbutton("//div[@class=\"MuiBox-root css-v0i3e8\"]/div[6]/a/div");
	}
	
	public void currenturl()
	{
		String currenturl= bp.getcurrenturl();
		System.out.println(currenturl);
	}
	
	public void scrolldowntoslider() throws InterruptedException
	{
		bp.scrolltoelement("//div[@class=\"MuiBox-root css-rfiegf\"]/div/div[2]/div/div/span/span[2]");
		
	}
	
	public void slidervalueverification() throws InterruptedException
	{
		Thread.sleep(20000);
		scrolldowntoslider();
		bp.slider("//div[@class=\"MuiBox-root css-rfiegf\"]/div/div[2]/div/div/span/span[3]",94);
		WebElement slidertextbox=element.findElement(By.xpath("//div[@class=\"MuiBox-root css-rfiegf\"]/div/div[2]/div/div/div/div/input"));
		assertEquals(slidertextbox.getAttribute("value"),"823","Text value is not same as Slider value");		
	}	
	
	public void slidertextverfication() throws InterruptedException
	{
		Thread.sleep(20000);
		element.findElement(By.xpath("//div[@class=\"MuiBox-root css-rfiegf\"]/div/div[2]/div/div/div/div/input")).sendKeys(Keys.BACK_SPACE,Keys.BACK_SPACE,Keys.BACK_SPACE,"560");
		WebElement sliderdragerball=element.findElement(By.xpath("//div[@class=\"MuiBox-root css-rfiegf\"]/div/div[2]/div/div/span/span[3]/input"));
		assertEquals(sliderdragerball.getAttribute("value"),"560","Slider value is not same as Text value");
	}
	
	public void CPTcheckboxverification() throws InterruptedException
	{
		Thread.sleep(20000);
		WebElement CPT99091=element.findElement(By.xpath("//div[@class=\"MuiBox-root css-1p19z09\"]/div/label/span/input"));
		WebElement CPT99453=element.findElement(By.xpath("//div[@class=\"MuiBox-root css-1p19z09\"]/div[2]/label/span/input"));
		WebElement CPT99454=element.findElement(By.xpath("//div[@class=\"MuiBox-root css-1p19z09\"]/div[3]/label/span/input"));
		WebElement CPT99474=element.findElement(By.xpath("//div[@class=\"MuiBox-root css-1p19z09\"]/div[8]/label/span/input"));
		bp.scrolldowntillelementvisible(CPT99091);
		bp.scrolldowntillelementvisible(CPT99453);
		bp.scrolldowntillelementvisible(CPT99454);
		bp.scrolldowntillelementvisible(CPT99474);

		
	}
	
	public void totalrecurringmonthreimbursementvalidation() throws InterruptedException
	{
		Thread.sleep(20000);
		WebElement slidertextbox=element.findElement(By.xpath("//div[@class=\"MuiBox-root css-rfiegf\"]/div/div[2]/div/div/div/div/input"));
		bp.scrolldowntillelementvisible(slidertextbox);
		slidertextbox.sendKeys(Keys.BACK_SPACE,Keys.BACK_SPACE,Keys.BACK_SPACE,"820");
		WebElement totalrecuramount=element.findElement(By.xpath("//div[@class=\"MuiBox-root css-19zjbfs\"]/div[3]/p[2]"));
		System.out.println(totalrecuramount.getText());
		assertEquals(totalrecuramount.getText(),"$110700","Total recurring reimbursement is incorrect");	
		
	}
	
	public void totalrecurringmonthreimbursementheadervalidation() throws InterruptedException
	{
		Thread.sleep(20000);
		element.findElement(By.xpath("//div[@class=\"MuiBox-root css-1a2y8js\"]/div")).sendKeys(Keys.ARROW_DOWN,Keys.ARROW_DOWN);
		WebElement totalrecuramountinheader=element.findElement(By.xpath("//div[@class=\"MuiBox-root css-3f59le\"]/div/header/div/p[4]/p"));
		System.out.println("Header is displayed "+totalrecuramountinheader.isDisplayed());
		System.out.println(totalrecuramountinheader.getText());
		assertEquals(totalrecuramountinheader.getText(),"$110700","Total recurring reimbursement is incorrect");
		
	}


}
